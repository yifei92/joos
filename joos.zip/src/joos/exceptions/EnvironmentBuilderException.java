package joos.exceptions;

import java.lang.Exception;

public class EnvironmentBuilderException extends Exception {

    public EnvironmentBuilderException(String message) {
        super(message);
    }

}