package joos.commons;

public class Ref<T> {
  public T ref;
}
