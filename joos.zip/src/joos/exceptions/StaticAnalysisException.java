package joos.exceptions;

/**
 * Created by yifei on 15/03/17.
 */
public class StaticAnalysisException extends Exception {

	public StaticAnalysisException(String message) {
		super(message);
	}

}