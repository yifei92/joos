package joos.ast;

import joos.commons.ParseTreeNode;
import joos.commons.ASTTreeNode;
import joos.exceptions.InvalidSyntaxException;

public class ASTBuilder {

	/**
	 * Given a parse tree converts it into ast.
	 */
	public ASTTreeNode convert(ParseTreeNode parseTree) throws InvalidSyntaxException {
		return null;
	}
}