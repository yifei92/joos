package joos.exceptions;

/**
 * Created by yifei on 24/02/17.
 */
public class TypeLinkingException extends Exception  {

    public TypeLinkingException(String message) {
        super(message);
    }
}
