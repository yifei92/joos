package joos.commons;

import joos.commons.ParseTreeNode;

/**
 * Created by yifei on 09/03/17.
 */
public class Type {
	public String name;
	public ParseTreeNode decl;
	public Type(String s){
		name=s;
	}
}
